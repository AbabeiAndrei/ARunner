﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ARunner.DataLayer.Model
{
    public enum UserAccess
    {
        Regular,
        Manager,
        Admin    
    }

    public enum UserState
    {
        Created,
        Invited,
        Active,
        Suspended
    }

    public class User
    {
        public int Id { get; set; }

        public string FullName { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime LastLoggedIn { get; set; }

        public UserState State { get; set; }

        public UserAccess Access { get; set; }

        public int RowVersion { get; set; }

        public RowState RowState { get; set; }

        public string Metadata { get; set; }

        [NotMapped]
        public UserSettings Settings => Metadata != null ? JsonConvert.DeserializeObject<UserSettings>(Metadata) : null;
    }
}
