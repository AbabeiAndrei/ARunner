﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ARunner.DataLayer.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MySQL.Data.EntityFrameworkCore.Extensions;

namespace ARunner.DataLayer
{
    public enum RowState : short
    {
        Created = 0,
        Deleted = 1
    }

    public class ADbContext : DbContext
    {
        private readonly IConfigurationRoot _config;

        public ADbContext(IConfigurationRoot config, DbContextOptions options)
            : base(options)
        {
            _config = config;
        }

        public DbSet<User> Users { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    var userBuilder = modelBuilder.Entity<User>();

        //    userBuilder.Property(u => u.Id)
        //               .IsRequired()
        //               .HasColumnName("id");
        //    userBuilder.HasKey(c => c.Id);

        //    userBuilder.Property(u => u.FullName)
        //               .IsRequired()
        //               .HasMaxLength(250)
        //               .HasColumnName("fullname");

        //    userBuilder.Property(u => u.Email)
        //               .IsRequired()
        //               .HasMaxLength(250)
        //               .HasColumnName("email");

        //    userBuilder.Property(u => u.Password)
        //               .IsRequired()
        //               .HasMaxLength(128)
        //               .HasColumnName("password");

        //    userBuilder.Property(u => u.CreatedAt)
        //               .ValueGeneratedOnAdd()
        //               .HasColumnName("created_at");

        //    userBuilder.Property(u => u.LastLoggedIn)
        //               .IsRequired(false)
        //               .HasColumnName("last_logged_in");

        //    userBuilder.Property(u => u.RowVersion)
        //               .IsRowVersion()
        //               .HasColumnName("row_version");

        //    userBuilder.Property(u => u.RowState)
        //               .IsRequired()
        //               .HasDefaultValue(RowState.Created)
        //               .HasColumnName("row_state");

        //    userBuilder.Property(u => u.Access)
        //               .IsRequired();

        //    userBuilder.Property(u => u.State)
        //               .HasDefaultValue(UserState.Created)
        //               .IsRequired()
        //               .HasColumnName("state");

        //    userBuilder.Property(u => u.Metadata)
        //               .HasColumnName("metadata");

        //    userBuilder.ToTable("users");
        //}

        protected override void OnConfiguring(DbContextOptionsBuilder buileBuilder)
        {
            base.OnConfiguring(buileBuilder);

            buileBuilder.UseMySQL(_config["connectionString"]);
        }
    }
}
